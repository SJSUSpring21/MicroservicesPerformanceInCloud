﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using MongoDB.Bson;
using MongoDB.Driver;

namespace MyMicroservice.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class YelpController : ControllerBase
    {
        private IMongoCollection<Yelp> _yelpCollection;

        public YelpController(IMongoClient client)
        {
            var database = client.GetDatabase("myFirstDatabase");
            _yelpCollection = database.GetCollection<Yelp>("myData");
        }

        [HttpGet]
        public IEnumerable<Yelp> Get()
        {
            return _yelpCollection.Find(y => y.Elite.Contains("2010")).Limit(1000).ToList();
        }
    }
}
