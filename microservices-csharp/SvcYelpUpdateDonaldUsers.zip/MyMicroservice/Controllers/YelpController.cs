﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using MongoDB.Bson;
using MongoDB.Driver;

namespace MyMicroservice.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class YelpController : ControllerBase
    {
        private IMongoCollection<Yelp> _yelpCollection;

        public YelpController(IMongoClient client)
        {
            var database = client.GetDatabase("myFirstDatabase");
            _yelpCollection = database.GetCollection<Yelp>("myData");
        }

        [HttpGet]
        public void Get()
        {
            var filter = Builders<Yelp>.Filter.Eq("Name", "Donald");
            var update = Builders<Yelp>.Update.Set("Review_Count", 10);
            _yelpCollection.UpdateOne(filter, update);
        }
    }
}
