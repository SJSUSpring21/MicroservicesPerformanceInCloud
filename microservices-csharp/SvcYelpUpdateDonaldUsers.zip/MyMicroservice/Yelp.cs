﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MyMicroservice
{
    [BsonIgnoreExtraElements]
    public class Yelp
    {
        [BsonId]
        public ObjectId Id { get; set; }

        [BsonElement("user_id")]
        public string User_Id { get; set; }

        [BsonElement("name")]
        public string Name { get; set; }

        [BsonElement("review_count")]
        public int Review_Count { get; set; }

        [BsonElement("yelping_since")]
        public string Yelping_since { get; set; }

        [BsonElement("useful")]
        public int Useful { get; set; }

        [BsonElement("funny")]
        public int Funny { get; set; }

        [BsonElement("cool")]
        public int Cool { get; set; }

        [BsonElement("elite")]
        public string Elite { get; set; }

        [BsonElement("fans")]
        public int Fans { get; set; }

        [BsonElement("average_stars")]
        public double Average_Stars { get; set; }

        [BsonElement("compliment_hot")]
        public int Compliment_hot { get; set; }

        [BsonElement("compliment_more")]
        public int Compliment_more { get; set; }

        [BsonElement("compliment_profile")]
        public int Compliment_profile { get; set; }

        [BsonElement("compliment_cute")]
        public int Compliment_cute { get; set; }

        [BsonElement("compliment_list")]
        public int Compliment_list { get; set; }

        [BsonElement("compliment_note")]
        public int Compliment_note { get; set; }

        [BsonElement("compliment_plain")]
        public int Compliment_plain { get; set; }

        [BsonElement("compliment_cool")]
        public int Compliment_cool { get; set; }

        [BsonElement("compliment_funny")]
        public int Compliment_funny { get; set; }

        [BsonElement("compliment_writer")]
        public int Compliment_writer { get; set; }

        [BsonElement("compliment_photos")]
        public int Compliment_photos { get; set; }
    }
}
